/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$(document).ready(function()
{
    $( "#SnChange" ).autocomplete({
        source: "../Resources/WebResponses/Autocomplete.php",
        minLength: 0
    });
    
    
    $('#newCustomer input').on( 'input', function() {
        var alertas = document.getElementById("alertas");
        setTimeout(() => {
            alertas.style.opacity = 0;
        }, 0); 
    }); 
});

function GetUser() {
    var usuario =       document.getElementById('SnChange').value;
    $.ajax({ //PERFORM AN AJAX CALL
        type:                   'post', 
        url:                    '../Resources/WebResponses/AddUserAJAX.php', //PHP CONTAINING ALL THE FUNCTIONS
        data:                   {usuario: usuario}, //SEND THE VALUE TO EXECUTE A QUERY WITH THE PALLET ID
        success: function(data) { //IF THE REQUEST ITS SUCCESSFUL
            var array = JSON.parse(data);
            if(array.SN !== "No User Found" ){
                for(var i = 1; i < document.getElementById('newCustomer').elements.length; i++){
                    document.getElementById('newCustomer').elements[i].disabled = false;
                }
                document.getElementById('SN').value =       array.SN;
                document.getElementById('First').value =    array.FirstName;
                document.getElementById('Last').value =     array.LastName;
                document.getElementById('Country').value =  array.Roster;
                document.getElementById('Email').value =    array.Email;
                document.getElementById('Phone').value =    array.Phone;
                if(array.Roster == "US"){
                    document.getElementById('State').value =    array.State;
                    document.getElementById('State').disabled = false;
                }
                document.getElementById('Type').value =     array.Type;
                var i = 1;
                $(".dayNum").each(function() {
                    $(this).val(array[i]);
                    i++;
                });
            }else{
                document.getElementById('newCustomer').reset();
                for(var i = 1; i < document.getElementById('newCustomer').elements.length; i++){
                    document.getElementById('newCustomer').elements[i].disabled = true;
                }
                DisplayError("User Not Found");
            }
        }
    });
}

function RevisarInfo(){
    var day;
    var sn =        document.getElementById('SN').value;
    var pass =      document.getElementById('Password').value;
    var cPass =     document.getElementById('CPassword').value;
    var first =     document.getElementById('First').value;
    var last =      document.getElementById('Last').value;
    var email =     document.getElementById('Email').value;
    var phone =     document.getElementById('Phone').value;
    var country =   document.getElementById('Country').options[document.getElementById('Country').selectedIndex].value;
    var state =     document.getElementById('State').options[document.getElementById('State').selectedIndex].value;
    var type =      document.getElementById('Type').options[document.getElementById('Type').selectedIndex].value;
    var schedule =  document.getElementById('Schedule').options[document.getElementById('Schedule').selectedIndex].value;
    var sponsor =   document.getElementById('Sponsor').options[document.getElementById('Sponsor').selectedIndex].value;
    var assign =    document.getElementById('Assignment').options[document.getElementById('Assignment').selectedIndex].value;
    //alert (schedule);
    //alert (sn + " " + pass + " " + cPass + " " + first + " " + last + " " + country + " " + state + " " + type);
    var days =      new Array();
    if(sn.length >= 5){
        if(pass === cPass){
            var info = new Array(sn, pass, cPass, first, last, email, country, state, type, schedule, phone, sponsor, assign);
            $.ajax({ //PERFORM AN AJAX CALL
                type:                   'post', 
                url:                    '../Resources/WebResponses/AddUserAJAX.php', //PHP CONTAINING ALL THE FUNCTIONS
                data:                   {informacion: info}, //SEND THE VALUE TO EXECUTE A QUERY WITH THE PALLET ID
                success: function(data) { //IF THE REQUEST ITS SUCCESSFUL
                    DisplayError(data);
                    window.parent.$("body").animate({scrollTop:0}, 'fast');
                    if(data == "User Added Successfully"){
                        document.getElementById('newCustomer').reset();
                    }
                }
            });
        }else{
            document.getElementById("Password").focus();
            document.getElementById("Password").select();
            DisplayError("Passwords Must Match");
            window.parent.$("body").animate({scrollTop:0}, 'fast');
        }
    }else{
        DisplayError("Username Must Include At Least 5 characters");
        window.parent.$("body").animate({scrollTop:0}, 'fast');
    }
    return false;
}

function EnableStates(e){
    if(e == "US"){
        document.getElementById('State').disabled = false;
    }else{
        document.getElementById('State').disabled = true;
    }
}

function UpdateInfo(){
    var day;
    var sn =        document.getElementById('SN').value;
    var pass =      document.getElementById('Password').value;
    var cPass =     document.getElementById('CPassword').value;
    var first =     document.getElementById('First').value;
    var last =      document.getElementById('Last').value;
    var email =     document.getElementById('Email').value;
    var phone =     document.getElementById('Phone').value;
    var status =    document.getElementById('Status').options[document.getElementById('Status').selectedIndex].value;
    var country =   document.getElementById('Country').options[document.getElementById('Country').selectedIndex].value;
    var state =     document.getElementById('State').options[document.getElementById('State').selectedIndex].value;
    var type =      document.getElementById('Type').options[document.getElementById('Type').selectedIndex].value;
    var schedule =  document.getElementById('Schedule').options[document.getElementById('Schedule').selectedIndex].value;
    var sponsor =   document.getElementById('Sponsor').options[document.getElementById('Sponsor').selectedIndex].value;
    var assign =    document.getElementById('Assignment').options[document.getElementById('Assignment').selectedIndex].value;
    
    //alert (sn + " " + pass + " " + cPass + " " + first + " " + last + " " + country + " " + state + " " + type);
    var days =      new Array();
    if(sn.length >= 5){
        if(pass === cPass){
            var info = new Array(sn, pass, cPass, first, last, email, country, state, type, status, schedule, phone, sponsor, assign);
            $.ajax({ //PERFORM AN AJAX CALL
                type:                   'post', 
                url:                    '../Resources/WebResponses/AddUserAJAX.php', //PHP CONTAINING ALL THE FUNCTIONS
                data:                   {updateInfo: '1', informacion: info}, //SEND THE VALUE TO EXECUTE A QUERY WITH THE PALLET ID
                success: function(data) { //IF THE REQUEST ITS SUCCESSFUL
                    DisplayError(data);
                    window.parent.$("body").animate({scrollTop:0}, 'fast');
                    if(data == "User Updated Successfully"){
                        document.getElementById('newCustomer').reset();
                    }else if(data == "Passwords Must Be At Least 5 Characters Long"){
                        document.getElementById("Password").focus();
                        document.getElementById("Password").select();
                    }
                }
            });
        }else{
            document.getElementById("Password").focus();
            document.getElementById("Password").select();
            DisplayError("Passwords Must Match");
            window.parent.$("body").animate({scrollTop:0}, 'fast');
        }
    }else{
        //alert("Username Must Include At Least 5 characters");
        DisplayError("Username Must Include At Least 5 characters");
        window.parent.$("body").animate({scrollTop:0}, 'fast');
    }
    return false;
}

function DisplayError(e){
    var alertas = document.getElementById("alertas");
    alertas.innerHTML = "";
    alertas.innerHTML = e;
    setTimeout(() => {
        alertas.style.opacity = 1;
    }, 0);   
}